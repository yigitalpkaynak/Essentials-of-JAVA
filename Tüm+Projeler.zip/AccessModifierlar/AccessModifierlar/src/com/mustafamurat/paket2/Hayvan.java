/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mustafamurat.paket2;

public class Hayvan {
    protected String isim;

    public Hayvan(String isim) {
        this.isim = isim;
    }
    
    
}
