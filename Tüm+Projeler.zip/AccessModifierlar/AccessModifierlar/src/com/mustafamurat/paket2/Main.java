
package com.mustafamurat.paket2;

public class Main {
    
   /* public static void main(String[] args) {
        Araba araba = new Araba();
        System.out.println(araba.model);
        System.out.println(araba.renk);
        System.out.println(araba.yil);
        
       
        
        
    }*/
    
    
    
    
    
}
