
public class Main {
    public static void main(String[] args) {
        
      Database database = new Database();
      database.baglantiKur("root","12345");
      
        
    }
    
}
