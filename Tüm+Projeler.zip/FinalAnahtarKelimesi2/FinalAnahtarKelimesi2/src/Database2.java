
public class Database2 extends Database{
    
    
    
}
