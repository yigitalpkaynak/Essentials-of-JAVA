
public class Main {
    public static void main(String[] args) {
        // Double : 64 bit - 8 byte
        // Float : 32 bit - 4 byte
        
        // Otomatik Dönüştürme :  int --> float ---> double
        
       double sayi1 = 70.25;
       double sayi2 = 60d;
       double sayi3 = 80.2;
       
       float a = 70.25f;
       float b = 60f;
       float c = 80.2f;
        System.out.println("Ortalama: " + (sayi1 + sayi2 + sayi3) / 3 );
        System.out.println("Ortalama2: " + (a + b + c) / 3 );
        
       
       
       
        
        
        
        
        
        
        
        
        
    }
}
