
public class Test {
    
    public static void main(String[] args) {
        
       // Account account1 = new Account();
        
        Account account2 = new Account("123213",1000.0,"Mustafa Murat Coşkun","coskun.m.murat@gmail.com","324324");
        
       // account2.paraYatir(500);
        
        
        account2.paraCekme(2000);
    }
    
}
