
public class Main {
    
    public static void main(String[] args) {
        int a = 10;
        
        int b = a * 2;
        
        int c = a * b * 2;
        
        int toplam = a + b + c;
        
        toplam = toplam - 5;
        System.out.println("Toplam = " + toplam);
                
    }
    
}
